public class QuickSort implements Sorter 
{
	public void Sort() 
	{
		System.out.println("QuickSort Process");
	}
}
