public class InsertSort implements Sorter 
{
	public void Sort() 
	{
		System.out.println("InsertSort Process");
	}
}
