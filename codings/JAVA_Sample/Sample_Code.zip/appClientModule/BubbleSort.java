public class BubbleSort implements Sorter 
{
	public void Sort() 
	{
		System.out.println("BubbleSort Process");
	}
}
