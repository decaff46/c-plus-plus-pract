public interface Sorter 
{
	public void Sort();
}
